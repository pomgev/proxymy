import sys

def add_folder_to_sys_path(folder_path):
  sys.path.insert(0, folder_path)