# Contributing

We are open for improvements through pull requests. Please open an issue first to explain the changes you want to make.

## Installation
Follow the instructions in the README.
